package Map;


public enum TileType {
    EMPTY, HOUSE, TREE, LAKE, FARM, GRASS;
}

